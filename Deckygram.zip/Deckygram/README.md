# Deckygram

SteamOS Decky plugin that shows Telegram Web chats and text replies in the Steam Deck Quick Access Menu. Deckygram uses Decky's native Steam UI components and runs Telegram Web in a hidden Electron window, reading its visible interface through a local bridge. It does not capture or broadcast gameplay.

## Features

- Sign in by scanning Telegram Web's QR code from Telegram on another device.
- Keep the Telegram Web login profile in Decky's plugin runtime directory.
- Browse visible chats with profile pictures and unread counters, read recent messages as chat bubbles with photos, stickers and sent/read ticks, see when someone is typing, and send text replies.
- Show all chats or direct messages only, hide the Archived Chats folder, choose Steam notification popups (with or without sound), and log out, all from Deckygram settings.
- Navigate chats, conversation controls, and replies with Steam Deck controller focus.

## Build

Build on SteamOS or a compatible x86_64 Linux environment. The Decky CLI/Docker setup is required for the complete plugin package.

```bash
pnpm install
pnpm run build
```

The VS Code `build` task stages the Telegram Web bridge app from `electron/telegram-web` into the packaged plugin's `bin` directory. The first launch downloads the pinned Electron runtime from the official Electron GitHub release and verifies it against that release's SHA-256 manifest. It uses SteamOS's system CA certificates for HTTPS verification and reports an actionable error if the trust store is unavailable. When Decky's backend does not inherit the desktop session environment, Deckygram searches the current user's runtime directory for a Wayland socket and launches Electron with the Wayland Ozone backend. Electron's child environment excludes temporary PyInstaller `_MEI` library-path entries to avoid conflicts with SteamOS system libraries. Deckygram uses a dedicated `profile-v3` directory and exclusive profile lock so two bridge instances cannot open the same Chromium databases concurrently; earlier `profile` and `profile-v2` directories are preserved until you log out. This isolated profile may require signing in again by QR code. Electron shutdown signals its whole process group to prevent leftover renderer processes from retaining profile database locks. The private Electron log records Telegram network failures using only the resource type, host, filename, and error/status, plus redacted renderer console warnings/errors and basic page-bootstrap counts; query strings and chat content are not logged. Electron startup failures include the tail of this log, which can help diagnose SteamOS display or library issues. The runtime profile and Electron archive are cached in the plugin runtime directory; neither is included in the plugin package.

## First Run

The first launch needs an internet connection to download Electron and open Telegram Web. Deckygram displays Telegram Web's QR code; on your phone, open Telegram and go to **Settings > Devices > Link Desktop Device** to scan it. The authenticated browser profile is retained for later launches.

## Settings and Notifications

Open **Settings** (the gear icon) from the chat list. Settings are saved in Decky's plugin settings directory.

- **Chats:** show all chats or direct messages only, and hide the Archived Chats folder. Direct messages are identified from the peer ID in each Telegram Web chat link (users are positive, groups and channels negative).
- **Notifications:** Steam notification popups or no popups, notification sound on or off, and unread counters for all chats, direct messages only, or off. Notifications come from increases in visible unread counts while Deckygram's Decky backend and Telegram Web session are running. Muted chats and the Archived Chats folder never notify.
- **Account:** **Log out** stops Telegram Web and deletes every stored Deckygram Telegram profile on the Deck, then shows a new login QR code. Telegram Web offers no programmatic sign-out, so the Deck may stay listed under **Settings > Devices** on your phone until you remove it there.

## Quick Access Menu

Deckygram runs directly in the Decky QAM panel and uses Decky controls for controller navigation. To add Deckygram as a dedicated icon in the QAM tab bar, install the separate [Quick Tab plugin](https://github.com/moi952/decky-quick-tab/releases/latest), open its settings, and pin Deckygram. Quick Tab manages the tab-bar entry; it is not bundled with Deckygram.

## Scope

This web bridge supports the visible chat list, currently rendered messages, and text replies. When no messages are extracted, Deckygram shows structural counts and a short list of visible scrollable conversation DOM regions outside the chat list to help distinguish a selector mismatch from an unloaded conversation; message content is not included in those diagnostics. Photos, static stickers and video preview frames that Telegram Web has already loaded are shown in chat, fetched once per message at up to 360 px and cached in the panel; select a photo or sticker (A, or tap it) to open a full-screen viewer with the original image Telegram loaded, and **Save to Downloads** writes it to a `Telegram` folder inside the Downloads folder reported by `xdg-user-dir DOWNLOAD` (falling back to `~/Downloads/Telegram`), as `telegram-<message id>.<ext>`, never overwriting an existing file; Deckygram does not play video or audio, send media, or implement chat search, group/topic selection, or calls. Profile pictures are copied from Telegram Web's loaded avatar images as small inline images, because Telegram's `blob:` URLs only resolve inside the hidden Electron window. Telegram Web's markup is not a stable API; changes to its UI may require updating the DOM mapping. The Electron process stays hidden and exposes only a token-protected HTTP bridge bound to loopback.
